library(testthat)
library(ClonalSim)

test_check("ClonalSim")
