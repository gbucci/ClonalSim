#' @keywords internal
"_PACKAGE"

#' ClonalSim: Simulation of Tumor Clonal Evolution with Realistic Sequencing Noise
#'
#' @description
#' ClonalSim generates realistic mutational profiles of tumor samples with
#' hierarchical clonal structure. It simulates founder, shared, and private
#' mutations with biologically realistic noise models.
#'
#' @details
#' The package implements a two-stage noise model:
#'
#' \strong{1. Biological Noise (Intra-Tumor Heterogeneity):}
#' \itemize{
#'   \item Uses Beta distribution (more realistic than Gaussian for frequencies)
#'   \item Models spatial/temporal heterogeneity within tumor
#'   \item Configurable concentration parameter controls variability
#' }
#'
#' \strong{2. Technical Sequencing Noise:}
#' \itemize{
#'   \item \strong{Depth overdispersion}: Negative binomial distribution
#'     (models GC bias, mappability, PCR artifacts)
#'   \item \strong{Stochastic read sampling}: Binomial distribution (each read
#'     independently sampled)
#'   \item \strong{Base calling errors}: Illumina-like error rates
#' }
#'
#' @section Main Functions:
#' \itemize{
#'   \item \code{\link{simulateTumor}}: Main simulation function
#'   \item \code{\link{ClonalSimData}}: S4 class for results
#'   \item \code{\link{toGRanges}}: Export to GenomicRanges
#'   \item \code{\link{toVCF}}: Export to VCF format
#'   \item \code{\link{toPyClone}}: Export for PyClone analysis
#'   \item \code{\link{toSciClone}}: Export for SciClone analysis
#' }
#'
#' @section Use Cases:
#' \itemize{
#'   \item \strong{Benchmarking}: Test variant callers and mutation detection pipelines
#'   \item \strong{Algorithm Development}: Test clonal deconvolution algorithms
#'   \item \strong{Education}: Teach tumor heterogeneity concepts
#'   \item \strong{Method Validation}: Positive controls for analysis pipelines
#' }
#'
#' @examples
#' # Basic simulation
#' sim <- simulateTumor()
#' sim
#'
#' # Access results
#' mutations <- getMutations(sim)
#' head(mutations)
#'
#' # Visualize
#' plot(sim, type = "vaf_density")
#'
#' # Export to Bioconductor
#' gr <- toGRanges(sim)
#'
#' # Custom simulation: low purity tumor
#' sim_low_purity <- simulateTumor(
#'   subclone_freqs = c(0.1, 0.15, 0.15)  # 40% purity
#' )
#'
#' # High coverage sequencing
#' sim_deep <- simulateTumor(
#'   sequencing_noise = list(mean_depth = 500, depth_dispersion = 100)
#' )
#'
#' @references
#' McGranahan N, Swanton C. Clonal Heterogeneity and Tumor Evolution: Past,
#' Present, and the Future. Cell. 2017.
#'
#' Dentro SC, Wedge DC, Van Loo P. Principles of Reconstructing the Subclonal
#' Architecture of Cancers. Cold Spring Harb Perspect Med. 2017.
#'
#' Roth A, et al. PyClone: statistical inference of clonal population structure
#' in cancer. Nat Methods. 2014.
#'
#' Miller CA, et al. SciClone: inferring clonal architecture and tracking the
#' spatial and temporal patterns of tumor evolution. PLoS Comput Biol. 2014.
#'
#' @name ClonalSim-package
#' @aliases ClonalSim
#'
## usethis namespace: start
## usethis namespace: end
NULL
